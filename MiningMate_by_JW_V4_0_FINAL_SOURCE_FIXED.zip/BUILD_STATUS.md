# Build Status — V4.0

Source prepared for Codemagic.
VersionCode: 5
VersionName: 4.0.0

Important: upload this ZIP to GitHub and make sure the root codemagic.yaml points to the same ZIP filename before starting a build.
