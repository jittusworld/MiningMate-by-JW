# MiningMate by JW — Android Framework V1.1

Native Android project foundation for MiningMate.

## Included
- Home dashboard
- Study
- MCQ / Mock Tests
- Mining Jobs
- Calculators & Tools
- Profile & Progress
- Bottom navigation
- Global one-step Back navigation
- Local SharedPreferences for basic app state
- MiningMate by JW branding

## Next development
Content database, real MCQ engine, bookmarks, job feed, calculators, notifications,
and production-ready UI will be added without replacing the navigation architecture.

This is source code, not a precompiled APK.

## V1.2 MCQ Engine
Functional starter MCQ flow with four options, scoring, percentage, retake and one-step back navigation.

## V1.3 Study Library
Expanded subject library, chapter study screens, notes/revision/MCQ entry points and local bookmarks.

## V1.4 Jobs Module
Mining jobs hub with demo listing cards, search, saved jobs and alerts entry points. Demo listings are not live/verified.

## V1.5 Tools Module
Functional production, cycle time, stripping ratio, air quantity and basic unit conversion calculators. One-step back navigation retained.

## V1.6 Profile & Progress
Progress counters, best score, local bookmarks, settings preference and reset progress are included. Data uses local SharedPreferences.

## V1.7 Search
Global MiningMate search entry from Home with local module/subject/tool/job search.

## V1.8 Polish
Updates & Alerts center and About screen added. Alert preference is stored locally for future notification integration.

## V1.9 Data Architecture
Added `app/src/main/assets/content.json` as the initial local content catalog.
This gives future chapters, notes and MCQs a structured data source without redesigning the app.

## V2.0 Content Integration
Added `assets/mcq_bank.json` with a structured starter MCQ bank.
The app's quiz currently contains the same starter questions; the next step is to load the JSON dynamically and expand it by chapter.

## V2.1 Dynamic MCQ Data Layer
The quiz now attempts to load `assets/mcq_bank.json` at runtime. If the JSON cannot be read, the built-in fallback questions remain available. MCQs also carry chapter_id and difficulty metadata for future chapter filters.

## V2.2 Study + MCQ Expansion
Added `assets/study_content.json` for 10 core chapters and expanded `assets/mcq_bank.json` to 100 structured starter questions (10 per subject).
This content is an educational starter dataset, not a substitute for official statutory text or site-specific rules.

## V2.3 App Flow
Study chapters now connect to data-driven Notes, Quick Revision and chapter-filtered MCQs using the local JSON assets.

## V2.4 Integrated Data Catalog
Added local `jobs.json` and `tools.json` catalogs. Jobs remain explicitly demo/unverified; no live vacancy claim is made. Tools now have structured metadata alongside the existing functional calculator screens.

## V2.5 Navigation
Navigation routing was tightened around a single history stack. Consecutive duplicate pushes are avoided, Back pops exactly one previous screen, and explicit Home navigation clears the stack.
Note: this source project has not been compiled in an Android SDK environment here.
