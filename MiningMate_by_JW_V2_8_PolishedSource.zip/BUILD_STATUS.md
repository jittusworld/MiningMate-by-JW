MiningMate by JW — V2.8

Purpose: polished Android source for Codemagic build.
Changes:
- Improved system-window handling so the app content does not overlap the Android status bar on newer Android versions.
- Version bumped to 2.8.0.
- Existing study, MCQ, jobs, tools, profile, search, updates and about modules retained.

Build: Codemagic workflow is expected to produce a debug APK from this source.
