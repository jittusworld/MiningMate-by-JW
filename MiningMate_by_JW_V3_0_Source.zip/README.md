# MiningMate by JW — V3.0 Same Reference UI

Android-first MiningMate by JW app source aligned to the supplied dark cinematic reference UI.

## Included
- MiningMate splash branding
- Matching dark/gold login screen
- Home dashboard with banner, Study, Jobs, Calculators, Current Affairs, Continue Learning and Daily MCQ
- Study subject library and chapter flow
- MCQ/test/result flow
- Mining Jobs
- Mining Calculators
- Profile & progress
- Notifications/About
- Five-tab bottom navigation
- One-step Back navigation through nested screens
- Local JSON content and MCQ bank
- Codemagic workflow configured for this ZIP

## Important
Jobs in the local dataset are demo/unverified. Statutory/regulatory study material should be verified against official DGMS/government publications before production release.
