MiningMate by JW V2.9 Polished UI
Target: match supplied MiningMate reference screens: dark cinematic black/gold theme, bottom navigation, card-based Home/Study/Jobs/Tools/Profile, splash screen, mining imagery, one-step Back navigation.
Note: source prepared for Codemagic. Local Android SDK build is not available in this environment.
