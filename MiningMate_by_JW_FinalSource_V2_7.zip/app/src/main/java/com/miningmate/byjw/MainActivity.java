package com.miningmate.byjw;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.*;
import android.widget.*;
import android.content.*;
import org.json.*;
import java.io.*;
import java.util.*;

public class MainActivity extends Activity {
    static final int BLACK=Color.rgb(11,13,16), CARD=Color.rgb(21,25,34), GOLD=Color.rgb(245,185,66), WHITE=Color.WHITE, MUTED=Color.rgb(170,177,190);
    LinearLayout root, content;
    final ArrayDeque<String> history=new ArrayDeque<>();
    SharedPreferences prefs;
    String current="home", selectedSubjectId="", selectedSubjectTitle="";
    String[][] questions=new String[0][0];
    int qIndex=0, score=0; boolean answered=false;

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("miningmate",MODE_PRIVATE); prefs.edit().putInt("visits",prefs.getInt("visits",0)+1).apply(); loadAllQuestions(); goHome(); }

    String asset(String name){ try{InputStream in=getAssets().open(name); ByteArrayOutputStream o=new ByteArrayOutputStream(); byte[] b=new byte[4096]; int n; while((n=in.read(b))!=-1)o.write(b,0,n); in.close(); return o.toString("UTF-8");}catch(Exception e){return null;} }
    void loadAllQuestions(){try{JSONObject r=new JSONObject(asset("mcq_bank.json")); JSONArray a=r.getJSONArray("questions"); questions=new String[a.length()][6]; for(int i=0;i<a.length();i++){JSONObject q=a.getJSONObject(i);JSONArray o=q.getJSONArray("options");questions[i][0]=q.getString("q");for(int j=0;j<4;j++)questions[i][j+1]=o.getString(j);questions[i][5]=String.valueOf((char)('A'+q.getInt("answer")));}}catch(Exception e){}}
    String[][] chapterQuestions(String id){ArrayList<String[]> out=new ArrayList<>();try{JSONArray a=new JSONObject(asset("mcq_bank.json")).getJSONArray("questions");for(int i=0;i<a.length();i++){JSONObject q=a.getJSONObject(i);if(!id.equals(q.optString("chapter_id")))continue;JSONArray o=q.getJSONArray("options");String[] x=new String[6];x[0]=q.getString("q");for(int j=0;j<4;j++)x[j+1]=o.getString(j);x[5]=String.valueOf((char)('A'+q.getInt("answer")));out.add(x);}}catch(Exception e){}return out.toArray(new String[0][0]);}

    TextView tv(String t,float s,int c,boolean bold){TextView v=new TextView(this);v.setText(t);v.setTextSize(s);v.setTextColor(c);v.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));v.setPadding(18,14,18,14);return v;}
    Button btn(String t,View.OnClickListener l){Button b=new Button(this);b.setText(t);b.setTextColor(WHITE);b.setAllCaps(false);b.setBackgroundColor(CARD);b.setOnClickListener(l);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,6,0,6);b.setLayoutParams(p);return b;}
    void base(String title){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BLACK);LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);if(!current.equals("home")){Button b=new Button(this);b.setText("‹ Back");b.setTextColor(GOLD);b.setAllCaps(false);b.setOnClickListener(v->goBack());bar.addView(b,new LinearLayout.LayoutParams(110,-2));}bar.addView(tv(title,21,WHITE,true),new LinearLayout.LayoutParams(0,-2,1));root.addView(bar);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(18,8,18,24);ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);}
    void goHome(){history.clear();current="home";render();}
    void show(String s){if(!current.equals(s))history.push(current);current=s;render();}
    void goBack(){if(!history.isEmpty()){current=history.pop();render();}else if(!current.equals("home"))goHome();}
    @Override public void onBackPressed(){goBack();}

    void render(){switch(current){case"home":home();break;case"study":study();break;case"jobs":jobs();break;case"tools":tools();break;case"profile":profile();break;case"search":search();break;case"updates":updates();break;case"about":about();break;case"mcq":quiz();break;case"result":result();break;case"notes":notes(false);break;case"revision":notes(true);break;default:chapter();}}

    void home(){base("MiningMate by JW");content.addView(tv("Learn • Prepare • Work • Grow",16,GOLD,true));content.addView(tv("Mining education, MCQs, jobs & practical tools",14,MUTED,false));content.addView(btn("📚 Study",v->show("study")));content.addView(btn("❓ MCQ Practice",v->{loadAllQuestions();qIndex=0;score=0;answered=false;show("mcq");}));content.addView(btn("💼 Mining Jobs",v->show("jobs")));content.addView(btn("🧮 Mining Tools",v->show("tools")));content.addView(btn("👤 Profile & Progress",v->show("profile")));content.addView(btn("🔎 Search",v->show("search")));content.addView(btn("🔔 Updates & Alerts",v->show("updates")));content.addView(btn("ℹ️ About",v->show("about")));}

    String[] ids={"cmr","vent","mach","safety","electric","methods","survey","blasting","haulage","geology"};
    String[] titles={"CMR 2017","Mine Ventilation","Mining Machinery","Mine Safety","Mining Electricity","Mining Methods","Mine Surveying","Explosives & Blasting","Haulage & Transport","Geology & Coal"};
    void study(){base("Study Library");content.addView(tv("Choose a subject",15,MUTED,false));for(int i=0;i<ids.length;i++){final int k=i;content.addView(btn(titles[i],v->{selectedSubjectId=ids[k];selectedSubjectTitle=titles[k];show("chapter");}));}}
    void chapter(){base(selectedSubjectTitle);content.addView(tv("Chapter module",15,GOLD,true));content.addView(btn("📖 Read Notes",v->show("notes")));content.addView(btn("⚡ Quick Revision",v->show("revision")));content.addView(btn("❓ Practice MCQs",v->{questions=chapterQuestions(selectedSubjectId);qIndex=0;score=0;answered=false;show("mcq");}));content.addView(btn("📝 Full Mock Test",v->{questions=chapterQuestions(selectedSubjectId);qIndex=0;score=0;answered=false;show("mcq");}));content.addView(btn("🔖 Bookmark Chapter",v->{prefs.edit().putBoolean("bm_"+selectedSubjectId,true).apply();Toast.makeText(this,"Chapter bookmarked",Toast.LENGTH_SHORT).show();}));}
    void notes(boolean rev){base(rev?"Quick Revision":"Study Notes");try{JSONArray a=new JSONObject(asset("study_content.json")).getJSONArray("subjects");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(selectedSubjectId.equals(o.getString("id"))){content.addView(tv(o.getString("summary"),15,WHITE,false));String key=rev?"revision_notes":"key_points";JSONArray x=o.getJSONArray(key);for(int j=0;j<x.length();j++)content.addView(tv((rev?"✓ ":"• ")+x.getString(j),14,WHITE,false));break;}}}catch(Exception e){content.addView(tv("Content unavailable.",15,MUTED,false));}}

    void quiz(){base("MCQ Practice");if(questions.length==0){content.addView(tv("No questions available.",16,MUTED,false));return;}if(qIndex>=questions.length){show("result");return;}String[] q=questions[qIndex];content.addView(tv("Question "+(qIndex+1)+" / "+questions.length,14,GOLD,true));content.addView(tv(q[0],18,WHITE,true));for(int i=1;i<=4;i++){final int k=i;content.addView(btn((char)('A'+i-1)+". "+q[i],v->answer(k)));}content.addView(tv("Score: "+score,14,MUTED,false));}
    void answer(int option){if(answered)return;answered=true;if(questions[qIndex][option].equals(questions[qIndex][1]))score++;Toast.makeText(this,option==1?"Correct":"Answer recorded",Toast.LENGTH_SHORT).show();content.addView(btn("Next Question",v->{qIndex++;answered=false;render();}));}
    void result(){base("Test Result");int pct=questions.length==0?0:(score*100/questions.length);content.addView(tv("Your Score: "+score+" / "+questions.length,22,WHITE,true));content.addView(tv("Percentage: "+pct+"%",18,GOLD,true));prefs.edit().putInt("tests",prefs.getInt("tests",0)+1).putInt("best",Math.max(pct,prefs.getInt("best",0))).apply();content.addView(btn("Retake Test",v->{qIndex=0;score=0;answered=false;show("mcq");}));}

    void jobs(){base("Mining Jobs");content.addView(tv("Demo listings • Verify official notification before applying",14,MUTED,false));try{JSONArray a=new JSONObject(asset("jobs.json")).getJSONArray("jobs");for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);content.addView(tv(j.getString("post")+" — "+j.getString("company"),17,WHITE,true));content.addView(tv(j.getString("location")+"\n"+j.getString("eligibility")+"\n"+j.getString("status"),13,MUTED,false));}}catch(Exception e){content.addView(tv("Jobs unavailable.",14,MUTED,false));}}
    void tools(){base("Mining Tools");content.addView(btn("Production Calculator",v->production()));content.addView(btn("Cycle Time Calculator",v->cycle()));content.addView(btn("Stripping Ratio",v->ratio()));content.addView(btn("Air Quantity Q = A × V",v->air()));content.addView(btn("Unit Converter",v->converter()));}
    EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(WHITE);e.setHintTextColor(MUTED);return e;}
    void production(){base("Production Calculator");EditText q=input("Quantity per cycle (tonnes)");EditText c=input("Number of cycles");content.addView(q);content.addView(c);TextView r=tv("Result",16,GOLD,true);content.addView(r);content.addView(btn("Calculate",v->{try{r.setText("Production = "+(Double.parseDouble(q.getText().toString())*Double.parseDouble(c.getText().toString()))+" tonnes");}catch(Exception e){r.setText("Enter valid numbers");}}));}
    void cycle(){base("Cycle Time");EditText a=input("Loading");EditText b=input("Hauling");EditText c=input("Dumping");EditText d=input("Return");content.addView(a);content.addView(b);content.addView(c);content.addView(d);TextView r=tv("Result",16,GOLD,true);content.addView(r);content.addView(btn("Calculate",v->{try{r.setText("Cycle time = "+(Double.parseDouble(a.getText().toString())+Double.parseDouble(b.getText().toString())+Double.parseDouble(c.getText().toString())+Double.parseDouble(d.getText().toString())));}catch(Exception e){r.setText("Enter valid numbers");}}));}
    void ratio(){base("Stripping Ratio");EditText w=input("Waste volume");EditText o=input("Coal/Ore volume");content.addView(w);content.addView(o);TextView r=tv("Result",16,GOLD,true);content.addView(r);content.addView(btn("Calculate",v->{try{r.setText("Stripping ratio = "+(Double.parseDouble(w.getText().toString())/Double.parseDouble(o.getText().toString())));}catch(Exception e){r.setText("Enter valid numbers");}}));}
    void air(){base("Air Quantity");EditText a=input("Area (m²)");EditText v=input("Velocity (m/s)");content.addView(a);content.addView(v);TextView r=tv("Result",16,GOLD,true);content.addView(r);content.addView(btn("Calculate",x->{try{r.setText("Q = "+(Double.parseDouble(a.getText().toString())*Double.parseDouble(v.getText().toString()))+" m³/s");}catch(Exception e){r.setText("Enter valid numbers");}}));}
    void converter(){base("Unit Converter");EditText e=input("Kilometres");content.addView(e);TextView r=tv("Result",16,GOLD,true);content.addView(r);content.addView(btn("Convert km → m",v->{try{r.setText((Double.parseDouble(e.getText().toString())*1000)+" m");}catch(Exception x){r.setText("Enter a valid number");}}));}

    void profile(){base("Profile & Progress");content.addView(tv("MiningMate by JW",20,WHITE,true));content.addView(tv("App visits: "+prefs.getInt("visits",0),15,MUTED,false));content.addView(tv("Tests completed: "+prefs.getInt("tests",0),15,MUTED,false));content.addView(tv("Best score: "+prefs.getInt("best",0)+"%",15,MUTED,false));content.addView(btn("Reset Progress",v->{prefs.edit().putInt("tests",0).putInt("best",0).apply();Toast.makeText(this,"Progress reset",Toast.LENGTH_SHORT).show();render();}));}
    void search(){base("Search MiningMate");EditText e=input("Search subject, tool or module");content.addView(e);content.addView(btn("Search",v->{String x=e.getText().toString().toLowerCase();for(int i=0;i<titles.length;i++)if(titles[i].toLowerCase().contains(x)){selectedSubjectId=ids[i];selectedSubjectTitle=titles[i];show("chapter");return;}if(x.contains("tool")||x.contains("calculator")){show("tools");return;}if(x.contains("job")){show("jobs");return;}Toast.makeText(this,"No matching module",Toast.LENGTH_SHORT).show();}));}
    void updates(){base("Updates & Alerts");content.addView(tv("MiningMate updates",18,WHITE,true));content.addView(tv("Keep app notifications enabled for future release updates.",14,MUTED,false));}
    void about(){base("About MiningMate");content.addView(tv("MiningMate by JW",24,GOLD,true));content.addView(tv("Learn • Prepare • Work • Grow",16,WHITE,true));content.addView(tv("Native Android mining education and career utility app.",14,MUTED,false));content.addView(tv("Version 2.7 • Final build-preparation source",14,MUTED,false));}
}
