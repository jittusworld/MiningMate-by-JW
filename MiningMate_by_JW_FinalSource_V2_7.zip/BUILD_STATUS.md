# MiningMate by JW — V2.7 Final Source

This package contains a cleaned native Android source project with the core app flow rebuilt in one MainActivity and the local JSON data layer.

## Included
- Home dashboard
- Study library with 10 subjects
- Notes / Quick Revision
- 100 structured MCQs
- Chapter-filtered practice
- Test result and progress
- Jobs demo data
- Mining calculators/tools
- Search
- Profile
- Updates/About
- One-step back navigation stack

## Build status
The source was structurally checked (balanced Java braces/parentheses and project files inspected), but an Android SDK/Gradle executable is not available in this environment, so an APK was not compiled or signed here.
