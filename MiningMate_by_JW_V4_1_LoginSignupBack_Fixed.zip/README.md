# MiningMate by JW — V4.1

Android-first Mining education, MCQs, jobs and practical tools app.

This build is based on the requested MiningMate reference UI: mining splash/logo, login, dashboard banner, study library, chapter pages, MCQ test/result flow, jobs, calculators, profile and one-step Back navigation.

Build: use Codemagic with the repository-level `codemagic.yaml`. The workflow expects `MiningMate_by_JW_V3_1_ReferenceUI.zip` in the repository root.


## V4.1 fixes
- Functional Sign Up screen and tab navigation.
- Back navigation: Sign Up → Login → Home, one screen at a time.
- Android system-bar insets fixed so content is not hidden under the status/navigation bars, including Android 15 edge-to-edge behavior.
