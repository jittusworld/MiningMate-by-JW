package com.miningmate.byjw;

import android.app.*;
import android.os.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.os.Build;
import android.widget.*;
import android.content.*;
import java.io.*;
import java.util.*;
import org.json.*;

public class MainActivity extends Activity {
    static final int BG=Color.rgb(6,10,13), CARD=Color.rgb(17,25,31), CARD2=Color.rgb(23,31,40), GOLD=Color.rgb(255,193,7), WHITE=Color.WHITE, MUTED=Color.rgb(160,170,180), GREEN=Color.rgb(22,210,125), RED=Color.rgb(245,82,82), BLUE=Color.rgb(65,155,215);
    LinearLayout root,content,bottom; SharedPreferences prefs; final ArrayDeque<String> history=new ArrayDeque<>();
    String current="home",selectedId="methods",selectedTitle="Coal Mining Methods"; String[][] questions=new String[0][0]; int qIndex=0,score=0;
    String[] ids={"methods","vent","mach","survey","safety","cmr","electric","blasting","haulage","geology"};
    String[] titles={"Coal Mining Methods","Mine Ventilation","Mining Machinery","Mine Surveying","Mine Safety","CMR 2017","Mining Electricity","Explosives & Blasting","Haulage & Transport","Geology & Coal"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        if(Build.VERSION.SDK_INT>=23){
            getWindow().getDecorView().setSystemUiVisibility(0);
        }
        prefs=getSharedPreferences("miningmate",MODE_PRIVATE);
        loadAllQuestions();
        showSplash();
    }
    int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(c);t.setTypeface(Typeface.create("sans",bold?Typeface.BOLD:Typeface.NORMAL));t.setIncludeFontPadding(false);return t;}
    GradientDrawable gd(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}
    GradientDrawable stroke(int c,int sc,float r){GradientDrawable g=gd(c,r);g.setStroke(dp(1),sc);return g;}

    // Android 15 (targetSdk 35) uses edge-to-edge by default. Keep all app content
    // below the status bar and above the navigation bar on every screen.
    void applySystemInsets(View v,int l,int t,int r,int b){
        v.setOnApplyWindowInsetsListener((view,insets)->{
            int top=0,bottom=0;
            if(Build.VERSION.SDK_INT>=30){
                android.graphics.Insets si=insets.getInsets(WindowInsets.Type.systemBars());
                top=si.top; bottom=si.bottom;
            }else if(Build.VERSION.SDK_INT>=23){
                top=insets.getSystemWindowInsetTop();
                bottom=insets.getSystemWindowInsetBottom();
            }
            view.setPadding(l,t+top,r,b+bottom);
            return insets;
        });
        v.requestApplyInsets();
    }

    void showSplash(){
        LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setGravity(Gravity.CENTER);l.setBackgroundColor(Color.BLACK);
        ImageView im=new ImageView(this);im.setImageResource(R.drawable.mine_splash);im.setScaleType(ImageView.ScaleType.CENTER_CROP);l.addView(im,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(l);
        applySystemInsets(l,0,0,0,0);
        new Handler().postDelayed(()->{prefs.edit().putInt("visits",prefs.getInt("visits",0)+1).apply();if(prefs.getBoolean("loggedIn",false)){current="home";history.clear();render();}else{current="login";history.clear();render();}},1500);
    }

    void login(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(18),dp(18),dp(14));
        ScrollView sv=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.mine_splash);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(logo,new LinearLayout.LayoutParams(-1,dp(255)));
        LinearLayout tabs=new LinearLayout(this);TextView loginTab=tab("Login",true),signupTab=tab("Sign Up",false);
        tabs.addView(loginTab,new LinearLayout.LayoutParams(0,dp(46),1));
        tabs.addView(signupTab,new LinearLayout.LayoutParams(0,dp(46),1));
        signupTab.setOnClickListener(v->push("signup"));
        box.addView(tabs);
        EditText email=input("✉  Email or Mobile Number");EditText pass=input("🔒  Password");pass.setInputType(0x81);box.addView(email);box.addView(pass);
        TextView forgot=tv("Forgot Password?",12,GOLD,true);forgot.setGravity(Gravity.RIGHT);forgot.setPadding(0,dp(5),dp(5),dp(8));box.addView(forgot,new LinearLayout.LayoutParams(-1,dp(30)));
        Button lb=primary("Login");box.addView(lb);lb.setOnClickListener(v->{prefs.edit().putBoolean("loggedIn",true).apply();current="home";history.clear();render();});
        LinearLayout or=new LinearLayout(this);or.setGravity(Gravity.CENTER_VERTICAL);or.addView(line(),new LinearLayout.LayoutParams(0,1,1));or.addView(tv("  OR  ",11,MUTED,false));or.addView(line(),new LinearLayout.LayoutParams(0,1,1));box.addView(or,new LinearLayout.LayoutParams(-1,dp(42)));
        Button google=secondary("G  Continue with Google");box.addView(google);google.setOnClickListener(v->{prefs.edit().putBoolean("loggedIn",true).apply();current="home";history.clear();render();});
        sv.addView(box);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);applySystemInsets(root,dp(18),dp(18),dp(18),dp(14));
    }

    void signup(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(18),dp(18),dp(14));
        ScrollView sv=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.mine_splash);logo.setScaleType(ImageView.ScaleType.CENTER_CROP);box.addView(logo,new LinearLayout.LayoutParams(-1,dp(180)));
        LinearLayout tabs=new LinearLayout(this);TextView loginTab=tab("Login",false),signupTab=tab("Sign Up",true);
        tabs.addView(loginTab,new LinearLayout.LayoutParams(0,dp(46),1));tabs.addView(signupTab,new LinearLayout.LayoutParams(0,dp(46),1));
        loginTab.setOnClickListener(v->goBack());box.addView(tabs);
        EditText name=input("👤  Full Name"),email=input("✉  Email or Mobile Number"),pass=input("🔒  Password"),confirm=input("🔒  Confirm Password");
        pass.setInputType(0x81);confirm.setInputType(0x81);box.addView(name);box.addView(email);box.addView(pass);box.addView(confirm);
        Button create=primary("Create Account");box.addView(create);
        create.setOnClickListener(v->{
            if(name.getText().toString().trim().isEmpty() || email.getText().toString().trim().isEmpty() || pass.getText().toString().isEmpty()){
                Toast.makeText(this,"Please fill all required fields.",Toast.LENGTH_SHORT).show();return;
            }
            if(!pass.getText().toString().equals(confirm.getText().toString())){
                Toast.makeText(this,"Passwords do not match.",Toast.LENGTH_SHORT).show();return;
            }
            prefs.edit().putBoolean("loggedIn",true).putString("name",name.getText().toString().trim()).apply();
            history.clear();current="home";render();
        });
        TextView backLogin=tv("Already have an account? Login",12,GOLD,true);backLogin.setGravity(Gravity.CENTER);backLogin.setPadding(0,dp(14),0,dp(10));box.addView(backLogin,new LinearLayout.LayoutParams(-1,dp(45)));backLogin.setOnClickListener(v->goBack());
        sv.addView(box);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);applySystemInsets(root,dp(18),dp(18),dp(18),dp(14));
    }
    TextView tab(String s,boolean active){TextView t=tv(s,12,active?BG:WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(gd(active?GOLD:CARD,10));return t;}
    View line(){View v=new View(this);v.setBackgroundColor(Color.rgb(55,65,75));return v;}
    Button primary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(BG);b.setTextSize(13);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(gd(GOLD,14));b.setMinHeight(0);b.setPadding(dp(8),0,dp(8),0);b.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(58)));return b;}
    Button secondary(String s){Button b=new Button(this);b.setText(s);b.setTextColor(BG);b.setTextSize(13);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(gd(WHITE,14));b.setMinHeight(0);b.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(54)));return b;}

    void shell(String title,boolean back){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);
        root.setPadding(dp(14),title.length()==0?0:dp(8),dp(14),0);
        if(title.length()>0){
            LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);
            if(back){TextView b=tv("‹",34,WHITE,false);b.setGravity(Gravity.CENTER);b.setOnClickListener(v->goBack());top.addView(b,new LinearLayout.LayoutParams(dp(42),dp(50)));}
            TextView h=tv(title,21,WHITE,true);top.addView(h,new LinearLayout.LayoutParams(0,dp(50),1));root.addView(top);
        }
        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,0,0,dp(10));
        ScrollView sv=new ScrollView(this);sv.setFillViewport(true);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        if(isTop(current))addBottom();setContentView(root);applySystemInsets(root,dp(14),title.length()==0?0:dp(8),dp(14),0);
    }
    boolean isTop(String s){return s.equals("home")||s.equals("study")||s.equals("jobs")||s.equals("tools")||s.equals("profile");}
    void addBottom(){bottom=new LinearLayout(this);bottom.setOrientation(LinearLayout.HORIZONTAL);bottom.setPadding(0,dp(2),0,dp(5));String[] icons={"⌂","▤","▣","⚒","●"};String[] names={"Home","Study","Jobs","Tools","Profile"};String[] dest={"home","study","jobs","tools","profile"};for(int i=0;i<5;i++){final String d=dest[i];LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setGravity(Gravity.CENTER);TextView ic=tv(icons[i],18,current.equals(d)?GOLD:MUTED,true);ic.setGravity(Gravity.CENTER);TextView nm=tv(names[i],10,current.equals(d)?GOLD:MUTED,false);nm.setGravity(Gravity.CENTER);item.addView(ic);item.addView(nm);item.setOnClickListener(v->topNav(d));bottom.addView(item,new LinearLayout.LayoutParams(0,dp(55),1));}root.addView(bottom);}
    void topNav(String s){if(current.equals(s)){render();return;}history.clear();current=s;render();}
    void push(String s){if(current.equals(s))return;history.push(current);current=s;render();}
    void goBack(){if(!history.isEmpty()){current=history.pop();render();}else if(!current.equals("home")){current="home";render();}else{super.onBackPressed();}}
    @Override public void onBackPressed(){goBack();}
    void render(){switch(current){case"home":home();break;case"study":study();break;case"chapter":chapter();break;case"notes":notes(false);break;case"revision":notes(true);break;case"signup":signup();break;case"mcq":quiz();break;case"result":result();break;case"jobs":jobs();break;case"tools":tools();break;case"profile":profile();break;case"updates":updates();break;case"about":about();break;default:home();}}

    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(14),dp(13),dp(14),dp(13));c.setBackground(gd(CARD,16));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,dp(5),0,dp(5));c.setLayoutParams(p);return c;}
    TextView iconBox(String icon,int color){TextView x=tv(icon,20,WHITE,true);x.setGravity(Gravity.CENTER);x.setBackground(gd(color,12));x.setPadding(dp(8),dp(6),dp(8),dp(6));return x;}
    EditText input(String h){EditText e=new EditText(this);e.setHint(h);e.setTextColor(WHITE);e.setHintTextColor(MUTED);e.setSingleLine(true);e.setTextSize(13);e.setBackground(gd(CARD,12));e.setPadding(dp(14),0,dp(14),0);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(52));p.setMargins(0,dp(6),0,dp(6));e.setLayoutParams(p);return e;}

    void home(){
        shell("",false); // intentionally no visible title; dashboard starts immediately below status bar
        content.removeAllViews();
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);left.addView(tv("Good Morning, "+prefs.getString("name","Jitesh")+"! 👋",18,WHITE,true));left.addView(tv("Keep Learning, Keep Growing",11,MUTED,false));header.addView(left,new LinearLayout.LayoutParams(0,dp(58),1));
        TextView bell=tv("♧",23,WHITE,true);bell.setGravity(Gravity.CENTER);bell.setOnClickListener(v->push("updates"));header.addView(bell,new LinearLayout.LayoutParams(dp(42),dp(46)));ImageView avatar=new ImageView(this);avatar.setImageResource(R.drawable.profile_avatar);avatar.setScaleType(ImageView.ScaleType.CENTER_CROP);avatar.setBackground(gd(Color.DKGRAY,50));header.addView(avatar,new LinearLayout.LayoutParams(dp(42),dp(42)));content.addView(header);
        FrameLayout hero=new FrameLayout(this);hero.setBackground(gd(CARD2,18));ImageView img=new ImageView(this);img.setImageResource(R.drawable.mine_banner);img.setScaleType(ImageView.ScaleType.CENTER_CROP);hero.addView(img,new FrameLayout.LayoutParams(-1,dp(132)));LinearLayout ov=new LinearLayout(this);ov.setOrientation(LinearLayout.VERTICAL);ov.setPadding(dp(15),dp(14),dp(10),dp(8));ov.setBackgroundColor(Color.argb(75,0,0,0));ov.addView(tv("BIG MINES\nBIGGER OPPORTUNITIES",20,GOLD,true));ov.addView(tv("Learn Today • Work Tomorrow",11,WHITE,true));hero.addView(ov,new FrameLayout.LayoutParams(-1,dp(132)));LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,dp(132));hp.setMargins(0,dp(5),0,dp(7));content.addView(hero,hp);
        LinearLayout g1=new LinearLayout(this);g1.setOrientation(LinearLayout.HORIZONTAL);g1.addView(homeTile("▤","Study","Notes • MCQs","study",Color.rgb(27,195,120)),new LinearLayout.LayoutParams(0,dp(92),1));g1.addView(homeTile("▣","Mining Jobs","Latest vacancies","jobs",Color.rgb(245,95,73)),new LinearLayout.LayoutParams(0,dp(92),1));content.addView(g1);
        LinearLayout g2=new LinearLayout(this);g2.setOrientation(LinearLayout.HORIZONTAL);g2.addView(homeTile("▦","Mining Calculators","Quick Calculations","tools",Color.rgb(130,75,220)),new LinearLayout.LayoutParams(0,dp(92),1));g2.addView(homeTile("▣","Current Affairs","Mining Updates","updates",Color.rgb(47,145,205)),new LinearLayout.LayoutParams(0,dp(92),1));content.addView(g2);
        TextView ct=tv("Continue Learning",18,WHITE,true);ct.setPadding(dp(3),dp(9),0,dp(3));content.addView(ct);LinearLayout cont=card();cont.setOnClickListener(v->{selectedId="methods";selectedTitle="Coal Mining Methods";push("chapter");});LinearLayout rr=new LinearLayout(this);rr.setGravity(Gravity.CENTER_VERTICAL);rr.addView(iconBox("⛏",Color.rgb(22,61,77)),new LinearLayout.LayoutParams(dp(55),dp(55)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(10),0,0,0);tx.addView(tv("Coal Mining Methods",15,WHITE,true));tx.addView(tv("12/20 topics completed",11,MUTED,false));tx.addView(tv("Progress 68%",11,GOLD,true));rr.addView(tx);cont.addView(rr);content.addView(cont);
        LinearLayout daily=card();daily.setOnClickListener(v->{loadAllQuestions();qIndex=0;score=0;push("mcq");});LinearLayout dr=new LinearLayout(this);dr.setGravity(Gravity.CENTER_VERTICAL);dr.addView(iconBox("🔥",Color.rgb(45,45,20)),new LinearLayout.LayoutParams(dp(55),dp(55)));LinearLayout dt=new LinearLayout(this);dt.setOrientation(LinearLayout.VERTICAL);dt.setPadding(dp(10),0,0,0);dt.addView(tv("Daily MCQ",15,WHITE,true));dt.addView(tv("10 New Questions",11,MUTED,false));dt.addView(tv("Test your knowledge today",10,MUTED,false));dr.addView(dt,new LinearLayout.LayoutParams(0,-2,1));TextView start=tv("Start Test",10,BG,true);start.setGravity(Gravity.CENTER);start.setBackground(gd(GOLD,12));daily.addView(dr);daily.addView(start,new LinearLayout.LayoutParams(dp(82),dp(34)));content.addView(daily);
    }
    View homeTile(String ico,String title,String sub,String dest,int c){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.HORIZONTAL);x.setGravity(Gravity.CENTER_VERTICAL);x.setPadding(dp(10),dp(7),dp(7),dp(7));x.setBackground(gd(CARD,16));TextView i=iconBox(ico,c);x.addView(i,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.setPadding(dp(8),0,0,0);t.addView(tv(title,12,WHITE,true));t.addView(tv(sub,9,MUTED,false));x.addView(t);x.setOnClickListener(v->push(dest));return x;}

    void study(){shell("Study",false);EditText e=input("⌕  Search topics...");content.addView(e);LinearLayout chips=new LinearLayout(this);chips.setPadding(0,dp(3),0,dp(5));String[] cs={"All","Mining Engg.","Safety","Legislation"};for(String c:cs){TextView chip=tv(c,10,c.equals("Mining Engg.")?BG:WHITE,true);chip.setGravity(Gravity.CENTER);chip.setBackground(gd(c.equals("Mining Engg.")?GOLD:CARD,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(34),1);p.setMargins(dp(2),0,dp(2),0);chips.addView(chip,p);}content.addView(chips);for(int i=0;i<ids.length;i++){final int k=i;LinearLayout c=card();LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);row.addView(iconBox(i==5?"⚖":"⛏",i==5?Color.rgb(110,45,48):Color.rgb(35,55,65)),new LinearLayout.LayoutParams(dp(44),dp(44)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(10),0,0,0);tx.addView(tv(titles[i],13,WHITE,true));tx.addView(tv(i==0?"Surface & Underground":i==1?"Theory & Numericals":i==2?"HEMM, Conveyors, Winders":"Basics • Notes • MCQs",10,MUTED,false));row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));row.addView(tv("›",25,MUTED,false));c.addView(row);c.setOnClickListener(v->{selectedId=ids[k];selectedTitle=titles[k];push("chapter");});content.addView(c);}}
    void chapter(){shell(selectedTitle,true);ImageView pic=new ImageView(this);pic.setImageResource(R.drawable.mine_banner);pic.setScaleType(ImageView.ScaleType.CENTER_CROP);content.addView(pic,new LinearLayout.LayoutParams(-1,dp(142)));LinearLayout tabs=new LinearLayout(this);String[] ts={"Notes","MCQs","Tests"};for(String s:ts){TextView t=tv(s,11,s.equals("Notes")?BG:WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(gd(s.equals("Notes")?GOLD:CARD,18));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(40),1);p.setMargins(dp(2),dp(6),dp(2),dp(6));tabs.addView(t,p);if(s.equals("MCQs"))t.setOnClickListener(v->{loadChapterQuestions();qIndex=0;score=0;push("mcq");});}content.addView(tabs);content.addView(tv("Progress 12/20 topics   •   68%",11,MUTED,false));String[] ns={"1. Introduction","2. Surface Mining Methods","3. Underground Mining Methods","4. Selection of Mining Method","5. Advantages and Disadvantages","6. Recent Advancements"};for(String n:ns)content.addView(actionRow("⛏",n,"Open notes & concepts",v->push("notes")));}
    LinearLayout actionRow(String ico,String title,String sub,View.OnClickListener l){LinearLayout c=card();LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);r.addView(iconBox(ico,Color.rgb(42,58,67)),new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout t=new LinearLayout(this);t.setOrientation(LinearLayout.VERTICAL);t.setPadding(dp(9),0,0,0);t.addView(tv(title,12,WHITE,true));t.addView(tv(sub,9,MUTED,false));r.addView(t,new LinearLayout.LayoutParams(0,-2,1));r.addView(tv("›",25,MUTED,false));c.addView(r);c.setOnClickListener(l);return c;}
    Button action(String s,View.OnClickListener l){Button b=new Button(this);b.setText(s);b.setTextColor(WHITE);b.setTextSize(12);b.setAllCaps(false);b.setGravity(Gravity.CENTER);b.setBackground(gd(CARD,14));b.setOnClickListener(l);b.setMinHeight(0);b.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(54)));return b;}
    void notes(boolean rev){shell(rev?"Quick Revision":selectedTitle,true);try{JSONArray a=new JSONObject(asset("study_content.json")).getJSONArray("subjects");for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);if(selectedId.equals(o.getString("id"))){content.addView(tv(o.optString("summary","Study material"),13,WHITE,false));JSONArray x=o.optJSONArray(rev?"revision_notes":"key_points");if(x!=null)for(int j=0;j<x.length();j++)content.addView(actionRow("✓",x.getString(j),"Key learning point",v->{}));break;}}}catch(Exception e){content.addView(tv("Content unavailable.",14,MUTED,false));}}
    void quiz(){shell("Daily MCQ Test",true);if(questions.length==0){content.addView(tv("No questions available.",16,MUTED,false));return;}if(qIndex>=questions.length){current="result";render();return;}TextView top=tv("Question "+(qIndex+1)+" of "+questions.length,12,MUTED,true);content.addView(top);LinearLayout q=card();q.addView(tv(questions[qIndex][0],15,WHITE,true));content.addView(q);for(int i=1;i<=4;i++){final int k=i;Button b=action((char)('A'+i-1)+"   "+questions[qIndex][i],v->answer(k));content.addView(b);}content.addView(tv("Score: "+score,11,MUTED,false));}
    void answer(int o){if(questions[qIndex][o].equals(questions[qIndex][5]))score++;qIndex++;render();}
    void result(){shell("Test Result",true);int pct=questions.length==0?0:score*100/questions.length;LinearLayout r=card();r.setGravity(Gravity.CENTER);r.addView(tv("🏆",45,GOLD,true));r.addView(tv("Great Job!",24,WHITE,true));r.addView(tv("You have completed the test",11,MUTED,false));r.addView(tv(score+" / "+questions.length,22,GREEN,true));r.addView(tv(pct+"% Score",17,GOLD,true));content.addView(r);prefs.edit().putInt("tests",prefs.getInt("tests",0)+1).putInt("best",Math.max(pct,prefs.getInt("best",0))).apply();content.addView(action("Review Answers",v->Toast.makeText(this,"Answer review coming with the full test engine.",Toast.LENGTH_SHORT).show()));content.addView(action("Try Another Test",v->{qIndex=0;score=0;push("mcq");}));}

    void jobs(){shell("Mining Jobs",false);EditText e=input("⌕  Search jobs, company...");content.addView(e);String[] filters={"All","Coal India","NCL","SECL","WCL"};LinearLayout f=new LinearLayout(this);for(String s:filters){TextView t=tv(s,9,s.equals("All")?BG:WHITE,true);t.setGravity(Gravity.CENTER);t.setBackground(gd(s.equals("All")?GOLD:CARD,16));f.addView(t,new LinearLayout.LayoutParams(0,dp(32),1));}content.addView(f);try{JSONArray a=new JSONObject(asset("jobs.json")).getJSONArray("jobs");for(int i=0;i<a.length();i++){JSONObject j=a.getJSONObject(i);content.addView(actionRow("N",j.getString("post"),j.getString("company")+" • "+j.getString("location"),v->{}));}}catch(Exception e2){content.addView(tv("Jobs unavailable.",14,MUTED,false));}}
    void tools(){shell("Mining Calculators",false);content.addView(actionRow("💥","Blasting Calculator","Powder factor, charge, spacing",v->Toast.makeText(this,"Calculator module next",Toast.LENGTH_SHORT).show()));content.addView(actionRow("▰","Haul Road Gradient","Ramping & grade calculation",v->Toast.makeText(this,"Calculator module next",Toast.LENGTH_SHORT).show()));content.addView(actionRow("▦","Production Calculator","Output, tonnage, productivity",v->production()));content.addView(actionRow("▤","Conveyor Design","Belt speed, capacity, power",v->Toast.makeText(this,"Calculator module next",Toast.LENGTH_SHORT).show()));content.addView(actionRow("💨","Ventilation Calculator","Air quantity, velocity, RVP",v->air()));content.addView(actionRow("⚒","Explosives Quantity","Charge per hole, total charge",v->Toast.makeText(this,"Calculator module next",Toast.LENGTH_SHORT).show()));content.addView(actionRow("▥","Mine Planning Tools","Stripping ratio, pit design",v->ratio()));content.addView(actionRow("↔","Unit Converter","Length, weight, pressure",v->converter()));}
    void calcBase(String title){shell(title,true);}void production(){calcBase("Production Calculator");EditText a=input("Quantity per cycle (tonnes)"),b=input("Number of cycles");content.addView(a);content.addView(b);TextView r=tv("Result",15,GOLD,true);content.addView(r);content.addView(action("Calculate",v->{try{r.setText("Production = "+Double.parseDouble(a.getText().toString())*Double.parseDouble(b.getText().toString())+" tonnes");}catch(Exception e){r.setText("Enter valid numbers");}}));}void ratio(){calcBase("Mine Planning Tools");EditText a=input("Waste volume"),b=input("Coal/Ore volume");content.addView(a);content.addView(b);TextView r=tv("Result",15,GOLD,true);content.addView(r);content.addView(action("Calculate",v->{try{r.setText("Stripping ratio = "+Double.parseDouble(a.getText().toString())/Double.parseDouble(b.getText().toString()));}catch(Exception e){r.setText("Enter valid numbers");}}));}void air(){calcBase("Ventilation Calculator");EditText a=input("Area (m²)"),b=input("Velocity (m/s)");content.addView(a);content.addView(b);TextView r=tv("Result",15,GOLD,true);content.addView(r);content.addView(action("Calculate Q",v->{try{r.setText("Q = "+Double.parseDouble(a.getText().toString())*Double.parseDouble(b.getText().toString())+" m³/s");}catch(Exception e){r.setText("Enter valid numbers");}}));}void converter(){calcBase("Unit Converter");EditText a=input("Kilometres");content.addView(a);TextView r=tv("Result",15,GOLD,true);content.addView(r);content.addView(action("Convert km → m",v->{try{r.setText(Double.parseDouble(a.getText().toString())*1000+" m");}catch(Exception e){r.setText("Enter valid number");}}));}

    void profile(){shell("Profile",false);LinearLayout h=card();h.setGravity(Gravity.CENTER_HORIZONTAL);ImageView p=new ImageView(this);p.setImageResource(R.drawable.profile_avatar);p.setScaleType(ImageView.ScaleType.CENTER_CROP);h.addView(p,new LinearLayout.LayoutParams(dp(78),dp(78)));h.addView(tv("Jitesh Patel\nMining Enthusiast",17,WHITE,true));content.addView(h);content.addView(actionRow("▣",prefs.getInt("tests",0)+" Tests Taken","80% Avg. Score • "+prefs.getInt("best",0)+"% Best",v->{}));content.addView(actionRow("🔖","My Bookmarks","Saved study topics",v->{}));content.addView(actionRow("⬇","Download Notes","Offline study material",v->{}));content.addView(actionRow("◷","Test History","Previous attempts",v->{}));content.addView(actionRow("▣","Saved Jobs","Your saved vacancies",v->{}));content.addView(actionRow("🔔","Notifications","Alerts and updates",v->push("updates")));content.addView(actionRow("⚙","App Settings","Preferences",v->Toast.makeText(this,"Settings module next",Toast.LENGTH_SHORT).show()));content.addView(actionRow("ⓘ","About MiningMate","Version 4.1",v->push("about")));}
    void updates(){shell("Updates & Alerts",true);content.addView(tv("🔔  MiningMate Updates",18,WHITE,true));content.addView(tv("New study content, MCQs, jobs and app releases will appear here.",13,MUTED,false));}
    void about(){shell("About MiningMate",true);content.addView(tv("MININGMATE by JW",24,GOLD,true));content.addView(tv("Learn • Prepare • Work • Grow",15,WHITE,true));content.addView(tv("Mining education, MCQs, jobs and practical tools.",13,MUTED,false));content.addView(tv("Version 4.1 • MiningMate by JW",12,MUTED,false));}

    void loadChapterQuestions(){loadAllQuestions();}
    String asset(String n){try{InputStream in=getAssets().open(n);ByteArrayOutputStream o=new ByteArrayOutputStream();byte[] b=new byte[4096];int z;while((z=in.read(b))!=-1)o.write(b,0,z);in.close();return o.toString("UTF-8");}catch(Exception e){return "{}";}}
    void loadAllQuestions(){try{JSONArray a=new JSONObject(asset("mcq_bank.json")).getJSONArray("questions");questions=new String[a.length()][6];for(int i=0;i<a.length();i++){JSONObject q=a.getJSONObject(i);JSONArray o=q.getJSONArray("options");questions[i][0]=q.getString("q");for(int j=0;j<4;j++)questions[i][j+1]=o.getString(j);questions[i][5]=String.valueOf((char)('A'+q.getInt("answer")));}}catch(Exception e){questions=new String[0][0];}}
}
