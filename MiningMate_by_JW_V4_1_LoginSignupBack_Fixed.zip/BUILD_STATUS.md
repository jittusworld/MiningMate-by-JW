# Build Status — V4.1

Source prepared for Codemagic.
VersionCode: 6
VersionName: 4.1.0

Fixes: Sign Up flow, one-step Back navigation, and Android system-bar/edge-to-edge layout insets.

Important: upload this ZIP to GitHub and make sure the repository-level codemagic.yaml points to the same ZIP filename before starting a build.
